package framework;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Address;
import org.web3j.abi.datatypes.Bool;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.abi.datatypes.generated.Bytes8;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tuples.generated.Tuple2;
import org.web3j.tuples.generated.Tuple3;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;

/**
 * <p>Auto generated code.
 * <p><strong>Do not modify!</strong>
 * <p>Please use the <a href="https://docs.web3j.io/command_line.html">web3j command line tools</a>,
 * or the org.web3j.codegen.SolidityFunctionWrapperGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 *
 * <p>Generated with web3j version 3.2.0.
 */
public class CommunityWork extends Contract {
    private static final String BINARY = "606060405260008054600160a060020a033316600160a060020a0319909116179055610a9b806100306000396000f3006060604052600436106100ae5763ffffffff7c0100000000000000000000000000000000000000000000000000000000600035041663207dc1e181146100b35780632f42c017146100dc57806341c0e1b5146101015780634df8e29814610116578063580db9a91461015e578063a60aa81914610191578063c653f6a914610202578063c867c61414610222578063c9c0e6dc14610237578063e4d91701146102de578063f565dede14610322575b600080fd5b6100c8600160c060020a031960043516610343565b604051901515815260200160405180910390f35b34156100e757600080fd5b6100ef610374565b60405190815260200160405180910390f35b341561010c57600080fd5b61011461037b565b005b341561012157600080fd5b610136600160c060020a0319600435166103a2565b6040519215158352901515602083015215156040808301919091526060909101905180910390f35b341561016957600080fd5b6101746004356103d8565b604051600160c060020a0319909116815260200160405180910390f35b61011460048035600160a060020a03169060248035919060649060443590810190830135806020601f82018190048102016040519081016040528181529291906020840183838082843750949650508435946020810135945060400135600160c060020a031916925061042c915050565b341561020d57600080fd5b6100c8600160c060020a0319600435166105ab565b6100c8600160c060020a0319600435166106b8565b341561024257600080fd5b610257600160c060020a031960043516610742565b604051600160a060020a038216602082015260408082528190810184818151815260200191508051906020019080838360005b838110156102a257808201518382015260200161028a565b50505050905090810190601f1680156102cf5780820380516001836020036101000a031916815260200191505b50935050505060405180910390f35b34156102e957600080fd5b6102fe600160c060020a03196004351661082c565b60405180848152602001838152602001828152602001935050505060405180910390f35b6100c8600160a060020a0360043516600160c060020a03196024351661085a565b600160c060020a03198116600090815260016020526040812060040154829042101561036e57600080fd5b50919050565b6002545b90565b60005433600160a060020a03908116911614156103a057600054600160a060020a0316ff5b565b600160c060020a03191660009081526001602052604090206006015460ff61010082048116926201000083048216929190911690565b60006002828154811015156103e957fe5b90600052602060002090600491828204019190066008029054906101000a900478010000000000000000000000000000000000000000000000000290505b919050565b600160c060020a031981166000908152600160208190526040909120805473ffffffffffffffffffffffffffffffffffffffff1916600160a060020a03891617815590810186905560028101858051610489929160200190610928565b50600381018490554283016004820155600681018054600160ff19909116811762ffff001916909155600280548083016104c383826109a6565b916000526020600020906004918282040191900660080285909190916101000a81548167ffffffffffffffff0219169083780100000000000000000000000000000000000000000000000090040217905550505060008611156105a25760408051908101604052600160a060020a03881681526020810187905260058201805461055082600183016109df565b8154811061055a57fe5b90600052602060002090600202016000820151815473ffffffffffffffffffffffffffffffffffffffff1916600160a060020a03919091161781556020820151600190910155505b50505050505050565b600160c060020a031981166000908152600160205260408120600401544211156105d457600080fd5b600160c060020a0319821660009081526001602052604090206006015462010000900460ff161580156106295750600160c060020a0319821660009081526001602081905260409091206006015460ff161515145b80156106575750600160c060020a03198216600090815260016020526040902060060154610100900460ff16155b156106b05750600160c060020a031981166000908152600160208190526040909120600601805476ffffffffffffffffffffffffffffffffffffffff0000001916630100000033600160a060020a031602179055610427565b506000610427565b600160c060020a031981166000908152600160208190526040808320909101543391600160a060020a0383169180156108fc029151600060405180830381858888f193505050501561073957600160c060020a031983166000908152600160208190526040909120600601805462ff0000191662010000179055915061036e565b6000915061036e565b61074a610a0b565b600160c060020a03198216600090815260016020818152604080842060068101546002918201805490956301000000909204600160a060020a03169486946101009383161593909302600019019091169290920491601f83018190048102019051908101604052809291908181526020018280546001816001161561010002031660029004801561081c5780601f106107f15761010080835404028352916020019161081c565b820191906000526020600020905b8154815290600101906020018083116107ff57829003601f168201915b5050505050915091509150915091565b600160c060020a03191660009081526001602081905260409091209081015460038201546004909201549092565b600160c060020a0319811660009081526001602081905260408083209091018054349081019091559080519081016040908152600160a060020a03861682526020808301849052600160c060020a03198616600090815260019182905291909120600501805490916108cf90839083016109df565b815481106108d957fe5b90600052602060002090600202016000820151815473ffffffffffffffffffffffffffffffffffffffff1916600160a060020a0391909116178155602082015181600101559050505092915050565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f1061096957805160ff1916838001178555610996565b82800160010185558215610996579182015b8281111561099657825182559160200191906001019061097b565b506109a2929150610a1d565b5090565b8154818355818115116109da5760030160049004816003016004900483600052602060002091820191016109da9190610a1d565b505050565b8154818355818115116109da576002028160020283600052602060002091820191016109da9190610a37565b60206040519081016040526000815290565b61037891905b808211156109a25760008155600101610a23565b61037891905b808211156109a257805473ffffffffffffffffffffffffffffffffffffffff1916815560006001820155600201610a3d5600a165627a7a723058204cd06e2ee8209c04d1266d3cd0f0e8771c245aaec960e572e30b267c0a9005330029";

    protected CommunityWork(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    protected CommunityWork(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    public RemoteCall<TransactionReceipt> endingProject(byte[] _projectId, BigInteger weiValue) {
        Function function = new Function(
                "endingProject", 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Bytes8(_projectId)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function, weiValue);
    }

    public RemoteCall<BigInteger> getProjectIdLength() {
        Function function = new Function("getProjectIdLength", 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<TransactionReceipt> kill() {
        Function function = new Function(
                "kill", 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<Tuple3<Boolean, Boolean, Boolean>> getProjectStatus(byte[] _projectId) {
        final Function function = new Function("getProjectStatus", 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Bytes8(_projectId)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}, new TypeReference<Bool>() {}, new TypeReference<Bool>() {}));
        return new RemoteCall<Tuple3<Boolean, Boolean, Boolean>>(
                new Callable<Tuple3<Boolean, Boolean, Boolean>>() {
                    @Override
                    public Tuple3<Boolean, Boolean, Boolean> call() throws Exception {
                        List<Type> results = executeCallMultipleValueReturn(function);;
                        return new Tuple3<Boolean, Boolean, Boolean>(
                                (Boolean) results.get(0).getValue(), 
                                (Boolean) results.get(1).getValue(), 
                                (Boolean) results.get(2).getValue());
                    }
                });
    }

    public RemoteCall<byte[]> getAllProjectId(BigInteger _index) {
        Function function = new Function("getAllProjectId", 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(_index)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bytes8>() {}));
        return executeRemoteCallSingleValueReturn(function, byte[].class);
    }

    public RemoteCall<TransactionReceipt> projectDeployer(String _projectOwnerAddress, BigInteger _allocatedFunds, String _projectDescription, BigInteger _targetAmount, BigInteger _fundingDuration, byte[] _projectId, BigInteger weiValue) {
        Function function = new Function(
                "projectDeployer", 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(_projectOwnerAddress), 
                new org.web3j.abi.datatypes.generated.Uint256(_allocatedFunds), 
                new org.web3j.abi.datatypes.Utf8String(_projectDescription), 
                new org.web3j.abi.datatypes.generated.Uint256(_targetAmount), 
                new org.web3j.abi.datatypes.generated.Uint256(_fundingDuration), 
                new org.web3j.abi.datatypes.generated.Bytes8(_projectId)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function, weiValue);
    }

    public RemoteCall<TransactionReceipt> acceptProject(byte[] _projectId) {
        Function function = new Function(
                "acceptProject", 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Bytes8(_projectId)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<TransactionReceipt> onCompletion(byte[] _projectId, BigInteger weiValue) {
        Function function = new Function(
                "onCompletion", 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Bytes8(_projectId)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function, weiValue);
    }

    public RemoteCall<Tuple2<String, String>> getProjectInfo(byte[] _projectId) {
        final Function function = new Function("getProjectInfo", 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Bytes8(_projectId)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Address>() {}));
        return new RemoteCall<Tuple2<String, String>>(
                new Callable<Tuple2<String, String>>() {
                    @Override
                    public Tuple2<String, String> call() throws Exception {
                        List<Type> results = executeCallMultipleValueReturn(function);;
                        return new Tuple2<String, String>(
                                (String) results.get(0).getValue(), 
                                (String) results.get(1).getValue());
                    }
                });
    }

    public RemoteCall<Tuple3<BigInteger, BigInteger, BigInteger>> getProjectValues(byte[] _projectId) {
        final Function function = new Function("getProjectValues", 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Bytes8(_projectId)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}));
        return new RemoteCall<Tuple3<BigInteger, BigInteger, BigInteger>>(
                new Callable<Tuple3<BigInteger, BigInteger, BigInteger>>() {
                    @Override
                    public Tuple3<BigInteger, BigInteger, BigInteger> call() throws Exception {
                        List<Type> results = executeCallMultipleValueReturn(function);;
                        return new Tuple3<BigInteger, BigInteger, BigInteger>(
                                (BigInteger) results.get(0).getValue(), 
                                (BigInteger) results.get(1).getValue(), 
                                (BigInteger) results.get(2).getValue());
                    }
                });
    }

    public RemoteCall<TransactionReceipt> addFunds(String _senderAddress, byte[] _projectId, BigInteger weiValue) {
        Function function = new Function(
                "addFunds", 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(_senderAddress), 
                new org.web3j.abi.datatypes.generated.Bytes8(_projectId)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function, weiValue);
    }

    public static RemoteCall<CommunityWork> deploy(Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit, BigInteger initialWeiValue) {
        return deployRemoteCall(CommunityWork.class, web3j, credentials, gasPrice, gasLimit, BINARY, "", initialWeiValue);
    }

    public static RemoteCall<CommunityWork> deploy(Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit, BigInteger initialWeiValue) {
        return deployRemoteCall(CommunityWork.class, web3j, transactionManager, gasPrice, gasLimit, BINARY, "", initialWeiValue);
    }

    public static CommunityWork load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return new CommunityWork(contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    public static CommunityWork load(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return new CommunityWork(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }
}
