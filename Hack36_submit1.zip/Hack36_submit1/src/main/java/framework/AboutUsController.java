package framework;

import javafx.fxml.Initializable;

import java.awt.event.MouseEvent;
import java.net.URL;
import java.util.ResourceBundle;

public class AboutUsController implements Initializable {



    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }


}
