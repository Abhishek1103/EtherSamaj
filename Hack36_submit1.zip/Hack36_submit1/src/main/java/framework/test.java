package framework;

import org.web3j.protocol.Web3j;
import org.web3j.protocol.http.HttpService;

public class test
{
    public static void main(String args[])
    {
        Web3j web3j = Web3j.build(new HttpService("https://rinkeby.infura.io/Nb9v0iQy5LYKUBBYu3Hp"));
    }
}
