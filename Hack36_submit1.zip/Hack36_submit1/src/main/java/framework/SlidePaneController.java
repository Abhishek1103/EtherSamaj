package framework;

import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

public class SlidePaneController implements Initializable {


    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
