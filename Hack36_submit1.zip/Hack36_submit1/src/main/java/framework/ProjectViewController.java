package framework;

import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

public class ProjectViewController implements Initializable {

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        /*
        * Display the project Description And Project Id
        */

    }

    public void onExit(){

    }

    public void onBack(){

    }

    public void onFundProjectButtonClicked(){

    }

    public void onUndertakeProjectButtonClicked(){

    }

    public void onProjectIdClicked(){

    }

    public void onAllotedFundsClicked(){

    }

    public void onProjectStatisticsClicked(){

    }
}
